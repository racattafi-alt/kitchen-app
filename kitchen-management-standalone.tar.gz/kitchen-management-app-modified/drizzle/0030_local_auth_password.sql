-- Migration: Add passwordHash for local auth (replaces Manus OAuth)
ALTER TABLE `users` ADD COLUMN `passwordHash` TEXT;
