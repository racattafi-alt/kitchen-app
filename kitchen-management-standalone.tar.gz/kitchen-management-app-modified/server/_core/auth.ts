/**
 * LOCAL AUTH — replaces Manus OAuth
 * Uses email + password with bcrypt hashing and JWT sessions via jose
 * No external OAuth server required
 */
import { SignJWT, jwtVerify } from "jose";
import { parse as parseCookieHeader } from "cookie";
import type { Request } from "express";
import * as db from "../db";
import { ENV } from "./env";
import { ForbiddenError } from "@shared/_core/errors";
import type { User } from "../../drizzle/schema";

export const COOKIE_NAME = "kitchen_session";
export const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1000;

function getSecretKey() {
  const secret = ENV.cookieSecret || "fallback-dev-secret-change-in-production";
  return new TextEncoder().encode(secret);
}

export async function hashPassword(password: string): Promise<string> {
  // Simple PBKDF2-based hashing using Web Crypto (no extra deps needed)
  const encoder = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey(
    "raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]
  );
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
    keyMaterial, 256
  );
  const hashArray = Array.from(new Uint8Array(bits));
  const saltArray = Array.from(salt);
  return saltArray.map(b => b.toString(16).padStart(2, "0")).join("") +
    ":" + hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  try {
    const [saltHex, hashHex] = stored.split(":");
    const salt = new Uint8Array(saltHex.match(/.{2}/g)!.map(b => parseInt(b, 16)));
    const encoder = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
      "raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]
    );
    const bits = await crypto.subtle.deriveBits(
      { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
      keyMaterial, 256
    );
    const hashArray = Array.from(new Uint8Array(bits));
    const computedHex = hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
    return computedHex === hashHex;
  } catch {
    return false;
  }
}

export async function createSessionToken(userId: string, name: string): Promise<string> {
  return new SignJWT({ userId, name })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setExpirationTime(Math.floor((Date.now() + ONE_YEAR_MS) / 1000))
    .sign(getSecretKey());
}

export async function verifySessionToken(token: string): Promise<{ userId: string; name: string } | null> {
  try {
    const { payload } = await jwtVerify(token, getSecretKey(), { algorithms: ["HS256"] });
    const { userId, name } = payload as Record<string, unknown>;
    if (typeof userId === "string" && typeof name === "string") {
      return { userId, name };
    }
    return null;
  } catch {
    return null;
  }
}

export async function authenticateRequest(req: Request): Promise<User> {
  const cookieHeader = req.headers.cookie;
  const cookies = cookieHeader ? parseCookieHeader(cookieHeader) : {};
  const sessionCookie = cookies[COOKIE_NAME];

  const session = await verifySessionToken(sessionCookie);
  if (!session) throw ForbiddenError("Invalid session");

  const user = await db.getUserByOpenId(session.userId);
  if (!user) throw ForbiddenError("User not found");

  return user;
}
