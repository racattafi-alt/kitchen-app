/**
 * LOCAL AUTH ROUTES — replaces Manus OAuth routes
 * POST /api/auth/login  — email + password login
 * POST /api/auth/register — create first admin account
 * GET  /api/auth/logout  — clear session cookie
 */
import type { Express, Request, Response } from "express";
import * as db from "../db";
import { hashPassword, verifyPassword, createSessionToken, COOKIE_NAME, ONE_YEAR_MS } from "./auth";

export function registerOAuthRoutes(app: Express) {
  // ─── LOGIN ───────────────────────────────────────────────
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    const { email, password } = req.body ?? {};
    if (!email || !password) {
      res.status(400).json({ error: "Email e password richiesti" });
      return;
    }

    try {
      const user = await db.getUserByEmail(email.toLowerCase().trim());
      if (!user || !user.passwordHash) {
        res.status(401).json({ error: "Credenziali non valide" });
        return;
      }

      const valid = await verifyPassword(password, user.passwordHash);
      if (!valid) {
        res.status(401).json({ error: "Credenziali non valide" });
        return;
      }

      const token = await createSessionToken(user.openId, user.name || "");
      res.cookie(COOKIE_NAME, token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: ONE_YEAR_MS,
        path: "/",
      });

      res.json({ success: true, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
    } catch (error) {
      console.error("[Auth] Login error:", error);
      res.status(500).json({ error: "Errore login" });
    }
  });

  // ─── REGISTER (first admin setup or invite) ──────────────
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    const { email, password, name } = req.body ?? {};
    if (!email || !password || !name) {
      res.status(400).json({ error: "Email, password e nome richiesti" });
      return;
    }
    if (password.length < 8) {
      res.status(400).json({ error: "Password deve essere almeno 8 caratteri" });
      return;
    }

    try {
      const existing = await db.getUserByEmail(email.toLowerCase().trim());
      if (existing) {
        res.status(409).json({ error: "Email già registrata" });
        return;
      }

      const passwordHash = await hashPassword(password);
      const openId = crypto.randomUUID();

      // First user becomes admin automatically
      const userCount = await db.getUserCount();
      const role = userCount === 0 ? "admin" : "user";

      await db.upsertUser({
        openId,
        name: name.trim(),
        email: email.toLowerCase().trim(),
        loginMethod: "email",
        passwordHash,
        role,
        lastSignedIn: new Date(),
      });

      const user = await db.getUserByOpenId(openId);
      if (!user) {
        res.status(500).json({ error: "Errore creazione utente" });
        return;
      }

      const token = await createSessionToken(user.openId, user.name || "");
      res.cookie(COOKIE_NAME, token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: ONE_YEAR_MS,
        path: "/",
      });

      res.json({ success: true, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
    } catch (error) {
      console.error("[Auth] Register error:", error);
      res.status(500).json({ error: "Errore registrazione" });
    }
  });

  // ─── LOGOUT ──────────────────────────────────────────────
  app.get("/api/auth/logout", (_req: Request, res: Response) => {
    res.clearCookie(COOKIE_NAME, { path: "/" });
    res.redirect("/");
  });

  // Keep old OAuth callback path for graceful redirect
  app.get("/api/oauth/callback", (_req: Request, res: Response) => {
    res.redirect("/");
  });
}
