# Kitchen Management System - Complete Export Package

## 🚀 Quick Start

This is a complete export of the Kitchen Management System application.

### Installation

```bash
# 1. Extract the archive
tar -xzf kitchen-management-app-export.tar.gz
cd kitchen-management-app

# 2. Install dependencies
pnpm install

# 3. Configure environment variables
# Create .env file with your database credentials and API keys
# See KITCHEN_APP_EXPORT_GUIDE.md section 5 for required variables

# 4. Setup database
pnpm db:push

# 5. Start development server
pnpm dev
```

Server will start on: http://localhost:3000

## 📚 Documentation

See **KITCHEN_APP_EXPORT_GUIDE.md** for complete documentation including:
- Project structure (434 files)
- Database schema (17 tables, 60+ migrations)
- Environment variables setup
- Deployment instructions
- Development guidelines
- API documentation

## 🏗️ Tech Stack

- **Frontend:** React 19 + TypeScript + Tailwind CSS 4 + Vite
- **Backend:** Express 4 + tRPC 11 + Node.js 22
- **Database:** MySQL/TiDB (Drizzle ORM)
- **UI Components:** shadcn/ui (70+ components)
- **Authentication:** Manus OAuth
- **Testing:** Vitest

## 📦 What's Included

- ✅ Complete source code (434 files, ~15MB uncompressed)
- ✅ Database schema + 60+ migrations
- ✅ 30+ React pages (Dashboard, Recipes, Production, Orders, etc.)
- ✅ tRPC API with 30+ routers (3000+ lines)
- ✅ Multi-store architecture with context
- ✅ Role-based access control (admin/user)
- ✅ Audit logging system
- ✅ 70+ shadcn/ui components
- ✅ Vitest test suite

## 🔑 Key Features

### Core Functionality
- **Multi-store management** - Manage multiple locations with data isolation
- **Recipe hierarchy** - Ingredients → Intermediates → Final Recipes
- **Automatic food cost calculation** - Recursive cost calculation through component tree
- **Production planning** - Plan weekly production with quantity management
- **Shopping list generation** - Auto-generate lists from orders
- **Supplier management** - Track suppliers and prices
- **Order tracking** - Complete order history with status

### Advanced Features
- **Multi-store editor** - Edit recipes/ingredients centrally, propagate to selected stores
- **Audit logs** - Track all critical actions (who, what, when, store)
- **Global search** - Search across all entities with keyboard navigation (/ to open)
- **Keyboard shortcuts** - ESC to dashboard, / for search
- **Responsive design** - Mobile-optimized with pagination
- **Role-based access** - Admin can switch stores, users see only their store

## 📁 Project Structure

```
kitchen-management-app/
├── client/                   # Frontend (React + TypeScript)
│   ├── src/
│   │   ├── components/       # 70+ UI components
│   │   ├── pages/            # 30+ page components
│   │   ├── contexts/         # Store + Theme contexts
│   │   ├── hooks/            # Custom hooks
│   │   └── lib/              # Utils + tRPC client
│   └── index.html
│
├── server/                   # Backend (Express + tRPC)
│   ├── _core/                # Framework (OAuth, context, LLM)
│   ├── routers.ts            # Main API (3000+ lines)
│   └── db.ts                 # Database helpers
│
├── drizzle/                  # Database
│   ├── schema.ts             # Schema (2000+ lines, 17 tables)
│   └── *.sql                 # 60+ migration files
│
├── shared/                   # Shared code
│   └── recipeValidation.ts
│
└── Configuration files
    ├── package.json
    ├── tsconfig.json
    ├── vite.config.ts
    └── drizzle.config.ts
```

## 🗄️ Database Schema

### 17 Tables

**Core:**
- `user` - Users with roles (admin/user)
- `stores` - Multi-store support

**Recipes:**
- `ingredients` - Base ingredients
- `intermediate_recipes` - Semi-finished products
- `final_recipes` - Finished recipes
- `recipe_components` - Component relationships

**Orders & Production:**
- `suppliers` - Supplier information
- `order_sessions` - Order history
- `order_items` - Order line items
- `productions` - Production records
- `production_items` - Production line items

**Tracking:**
- `audit_logs` - Action tracking

**Supporting:**
- `categories`, `measurement_types`, `storage_locations`, `fridges`, `waste_records`

## 🔧 Available Scripts

```bash
# Development
pnpm dev              # Start dev server (port 3000)
pnpm build            # Build for production
pnpm preview          # Preview production build

# Database
pnpm db:push          # Push schema to database
pnpm db:studio        # Open Drizzle Studio GUI

# Testing
pnpm test             # Run Vitest tests
pnpm test:ui          # Run tests with UI

# Code Quality
pnpm lint             # Run ESLint
pnpm format           # Format with Prettier
```

## 🌐 Deployment

### Manus Platform (Recommended)
Already configured - click "Publish" in Manus UI. All environment variables auto-injected.

### External Hosting (Vercel, Netlify, Railway)
1. Build: `pnpm build`
2. Set environment variables in platform dashboard
3. Deploy built files
4. Ensure MySQL/TiDB is accessible

See KITCHEN_APP_EXPORT_GUIDE.md section 13 for detailed deployment instructions.

## 🔐 Environment Variables

**Required variables** (see KITCHEN_APP_EXPORT_GUIDE.md section 5 for complete list):

```bash
DATABASE_URL=mysql://...
JWT_SECRET=...
OAUTH_SERVER_URL=https://api.manus.im
VITE_APP_ID=...
OWNER_OPEN_ID=...
OWNER_NAME=...
```

## 📞 Support

For detailed documentation, troubleshooting, and development guidelines:

👉 **See KITCHEN_APP_EXPORT_GUIDE.md** (complete 500+ line documentation)

### Quick Links in Guide
- Section 6: Installation & Setup
- Section 8: Multi-Store Architecture
- Section 9: Authentication & Authorization
- Section 10: Key Features Implementation
- Section 13: Deployment
- Section 15: Future Development Roadmap

## 📄 License

See KITCHEN_APP_EXPORT_GUIDE.md section 17 for license information.

---

**Export Date:** 2026-02-26  
**Version:** 33dbc060 (latest checkpoint)  
**Total Files:** 434  
**Compressed Size:** 512KB  
**Uncompressed Size:** ~15MB (excluding node_modules)

**Platform:** Manus (https://manus.im)
