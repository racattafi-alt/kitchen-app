import { useState } from "react";
import { ChefHat, Eye, EyeOff, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";

type Mode = "login" | "register";

export default function Login() {
  const [mode, setMode] = useState<Mode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [, setLocation] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/register";
    const body = mode === "login"
      ? { email, password }
      : { email, password, name };

    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        credentials: "include",
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Errore sconosciuto");
        return;
      }

      // Success — reload to trigger auth check
      window.location.href = "/dashboard";
    } catch {
      setError("Errore di connessione al server");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-500/20 rounded-2xl mb-4">
            <ChefHat className="h-9 w-9 text-emerald-400" />
          </div>
          <h1 className="text-3xl font-bold text-white">Kitchen Management</h1>
          <p className="text-slate-400 mt-1">Sistema professionale gestione cucina</p>
        </div>

        <Card className="border-slate-700 bg-slate-800/80 backdrop-blur-sm shadow-2xl">
          <CardHeader className="pb-4">
            <CardTitle className="text-white text-xl">
              {mode === "login" ? "Accedi" : "Crea Account"}
            </CardTitle>
            <CardDescription className="text-slate-400">
              {mode === "login"
                ? "Inserisci le tue credenziali per accedere"
                : "Crea il tuo account per iniziare"}
            </CardDescription>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === "register" && (
                <div className="space-y-1.5">
                  <Label htmlFor="name" className="text-slate-300">Nome</Label>
                  <Input
                    id="name"
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="Mario Rossi"
                    required
                    className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500 focus:border-emerald-500"
                  />
                </div>
              )}

              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-slate-300">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="mario@ristorante.it"
                  required
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500 focus:border-emerald-500"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="password" className="text-slate-300">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder={mode === "register" ? "Minimo 8 caratteri" : "••••••••"}
                    required
                    minLength={mode === "register" ? 8 : 1}
                    className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500 focus:border-emerald-500 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(v => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="bg-red-500/10 border border-red-500/30 rounded-lg px-4 py-3 text-red-400 text-sm">
                  {error}
                </div>
              )}

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-5 mt-2"
              >
                {loading
                  ? <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  : null}
                {mode === "login" ? "Accedi" : "Crea Account"}
              </Button>
            </form>

            <div className="mt-5 text-center text-sm text-slate-400">
              {mode === "login" ? (
                <>
                  Non hai un account?{" "}
                  <button
                    onClick={() => { setMode("register"); setError(""); }}
                    className="text-emerald-400 hover:text-emerald-300 font-medium"
                  >
                    Registrati
                  </button>
                </>
              ) : (
                <>
                  Hai già un account?{" "}
                  <button
                    onClick={() => { setMode("login"); setError(""); }}
                    className="text-emerald-400 hover:text-emerald-300 font-medium"
                  >
                    Accedi
                  </button>
                </>
              )}
            </div>

            {mode === "register" && (
              <p className="mt-4 text-xs text-slate-500 text-center">
                Il primo account creato diventa automaticamente amministratore.
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
