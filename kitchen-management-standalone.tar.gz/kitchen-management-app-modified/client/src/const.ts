export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

// Local auth — no external OAuth needed
export const getLoginUrl = () => "/login";
