# Kitchen Management System
### Versione standalone — nessuna dipendenza da Manus

Sistema professionale per la gestione cucina: ricette, food cost, produzione, HACCP, ordini.

---

## ✅ Cosa è cambiato rispetto alla versione Manus

| | Versione Manus | Questa versione |
|---|---|---|
| **Login** | Manus OAuth (api.manus.im) | Email + Password locale |
| **Hosting** | Solo piattaforma Manus | Qualsiasi server |
| **Env variables** | 10+ variabili Manus | Solo 2 variabili richieste |
| **Tracking** | Manus analytics | Nessuno |

---

## 🚀 Avvio rapido

### Prerequisiti
- Node.js 22+
- pnpm (`npm install -g pnpm`)
- MySQL 8+ (locale o cloud)

### 1. Installa dipendenze
```bash
pnpm install
```

### 2. Configura environment
```bash
cp .env.example .env
```
Modifica `.env`:
```bash
DATABASE_URL="mysql://user:password@localhost:3306/kitchen_db"
JWT_SECRET="genera-una-stringa-casuale-lunga-almeno-64-caratteri"
```

### 3. Setup database
```bash
pnpm db:push
```

### 4. Avvia in sviluppo
```bash
pnpm dev
```
→ Apri http://localhost:3000

### 5. Primo accesso
1. Vai su http://localhost:3000
2. Clicca "Registrati"
3. Crea il tuo account — **il primo account diventa automaticamente Admin**
4. Accedi e sei dentro!

---

## 🌐 Deploy su server esterno

### Opzione A — Railway (raccomandato, free tier disponibile)
1. Crea account su railway.app
2. Crea nuovo progetto → "Deploy from GitHub"
3. Aggiungi un database MySQL dal marketplace
4. Imposta le variabili d'ambiente:
   - `DATABASE_URL` — fornita da Railway automaticamente
   - `JWT_SECRET` — genera con: `node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"`
5. Deploy automatico ad ogni push

### Opzione B — VPS (Hetzner, DigitalOcean, ecc.)
```bash
# Build
pnpm build

# Start production
NODE_ENV=production pnpm start
```
Usa nginx come reverse proxy su porta 3000.

### Opzione C — Docker
```dockerfile
FROM node:22-alpine
WORKDIR /app
COPY . .
RUN npm install -g pnpm && pnpm install
RUN pnpm build
EXPOSE 3000
CMD ["node", "dist/index.js"]
```

---

## 🔐 Gestione utenti

- **Primo utente** = Admin automatico
- Gli admin possono cambiare ruoli dalla pagina `/users`
- Ruoli disponibili: `admin`, `manager`, `cook`, `user`
- Per aggiungere utenti: dalla pagina Users (solo admin) oppure via `/register`

---

## 📋 Features principali

- **Ingredienti** — gestione materie prime, fornitori, prezzi
- **Semilavorati** — ricette intermedie con calcolo costo
- **Ricette Finali** — piatti con food cost automatico ricorsivo
- **Food Matrix** — vista unificata tutti i prodotti
- **Produzione** — pianificazione settimanale
- **HACCP** — conformità e tracciabilità
- **Ordini** — lista spesa e storico ordini
- **Multi-store** — gestione più punti vendita

---

## 🛠 Script disponibili

```bash
pnpm dev          # Sviluppo (porta 3000)
pnpm build        # Build produzione
pnpm start        # Avvia build produzione
pnpm db:push      # Applica schema al database
pnpm test         # Esegui test
```

---

## ⚙️ Variabili d'ambiente

| Variabile | Richiesta | Descrizione |
|-----------|-----------|-------------|
| `DATABASE_URL` | ✅ | URL connessione MySQL |
| `JWT_SECRET` | ✅ | Secret per firmare i token JWT |
| `PORT` | ❌ | Porta server (default: 3000) |
| `VITE_APP_TITLE` | ❌ | Titolo app nel browser |

---

## 🔧 Architettura

```
client/          → React 19 + TypeScript + Tailwind 4
server/          → Express 4 + tRPC 11 + Node.js 22
drizzle/         → Schema MySQL + migrazioni
shared/          → Codice condiviso client/server
```

**Auth flow:**
1. Utente inserisce email + password su `/login`
2. POST `/api/auth/login` → verifica credenziali → crea JWT
3. JWT salvato come cookie `httpOnly`
4. Ogni richiesta tRPC verifica il cookie automaticamente
